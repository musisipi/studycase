﻿namespace studycase28
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Study Case 28");

            Console.Write("Masukkan angka 1-7 : ");
            double angka = Convert.ToDouble(Console.ReadLine());

            switch (angka)
            {
                case 1:
                    Console.WriteLine("Senin");
                    break;

                case 2:
                    Console.WriteLine("Selasa");
                    break;

                case 3:
                    Console.WriteLine("Rabu");
                    break;

                case 4:
                    Console.WriteLine("Kamis");
                    break;

                case 5:
                    Console.WriteLine("Jumat");
                    break;

                case 6:
                    Console.WriteLine("Sabtu");
                    break;

                case 7:
                    Console.WriteLine("Minggu");
                    break;

            }






        }
    }
}
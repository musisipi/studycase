﻿namespace studycase18
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            Console.WriteLine("program menentukan bilangan");

            Console.Write("Masukkan bilangan : ");
            double bil = Convert.ToDouble(Console.ReadLine()); 

            if (bil > 0 )
            {
                Console.WriteLine($"{bil} merupakan bilangan positif");

            }
            else if (bil < 0)
            {
                Console.WriteLine($"{bil} merupakan bilangan negatif");
            }
            else if (bil == 0) 
            {
                Console.WriteLine($"{bil} merupakan bilangan nol");
            }
        }
    }
}
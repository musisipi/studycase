﻿using System;

class Program
{
    // by NurFakhri
    static void Main()
    {
        Console.WriteLine("Pilihan Program:");
        Console.WriteLine("1. Menentukan Nilai Terbesar dan Terkecil dari Dua Nilai");
        Console.WriteLine("2. Menghitung Akar dan Menampilkan Hasil dalam Angka Bulat");
        Console.Write("Masukkan nomor program yang ingin dijalankan (1/2): ");
        int choice = Convert.ToInt32(Console.ReadLine());

        if (choice == 1)
        {
            Console.Write("Masukkan nilai pertama: ");
            double nilai1 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Masukkan nilai kedua: ");
            double nilai2 = Convert.ToDouble(Console.ReadLine());

            double nilaiTerbesar = Math.Max(nilai1, nilai2);
            double nilaiTerkecil = Math.Min(nilai1, nilai2);

            Console.WriteLine("Nilai terbesar adalah: " + nilaiTerbesar);


            Console.WriteLine("Nilai terkecil adalah: " + nilaiTerkecil);
            Console.ReadKey();
        }
        else if (choice == 2)
        {
            Console.WriteLine("+==================================+");
            Console.Write("Masukkan sebuah nilai: ");
            double nilai = Convert.ToDouble(Console.ReadLine());

            double akar = Math.Sqrt(nilai);

           
            double hasilBulat = Math.Round(akar);

            Console.WriteLine("Akar dari nilai tersebut adalah: " + hasilBulat);
            Console.ReadKey();

        }
    }
}
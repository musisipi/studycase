﻿using System;
using System.Linq;

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Program Menghitung Nilai Modulus");

            Console.WriteLine("========================================");
            Console.Write("Masukkan angka pertama: ");
            double angka1 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Masukkan angka kedua: ");
            double angka2 = Convert.ToDouble(Console.ReadLine());

            
            double modulus = angka1 % angka2;

            Console.WriteLine("========================================");
            Console.WriteLine("Nilai Modulus: " + modulus);
            Console.ReadKey();
        }
    }

﻿
// Create by NurFakhri || @nufakhri.id
using System;
using System.Linq;

public static class Program
{
  public static void Main()
  {
		double jari, _luas, _keliling, luas, keliling;
		
     Console.WriteLine("PROGRAM MENGHITUNG LUAS DAN KELILING LINGKARAN\n");
		 
		 
		 Console.Write("Jari-Jari :  ");
		 jari = Convert.ToDouble(Console.ReadLine());
		 
		 luas = 3.14 * jari * jari;
		 _luas = (22.0/7.0) * jari * jari;
		 keliling = 2 * 3.14 * jari;
		 _keliling = 2 * (22.0/7.0) * jari;
		 
		 Console.WriteLine("\nLuas lingkaran jika menggunakan π 3,14 adalah " + luas);
		 Console.WriteLine("Luas lingkaran jika menggunakan π 22/7 adalah " + _luas);
		 Console.WriteLine("Keliling lingkaran jika menggunakan π 3,14 adalah " + keliling);
		 Console.WriteLine("Keliling lingkaran jika menggunakan π 22/7 adalah " + _keliling);
  }
}

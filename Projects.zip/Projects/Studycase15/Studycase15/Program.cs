﻿using System;
using System.Linq;

namespace Studycase15;

  // Create By NurFakhri
	
public static class Program
{
  public static void Main()
  {
     Console.WriteLine("PROGRAM MENGHITUNG NILAI");
		 
		 Console.Write("Nilai Kehadiran : ");
		 double kehadiran = Convert.ToDouble(Console.ReadLine());
		 
		 Console.Write("Nilai Tugas     : ");
		 double tugas = Convert.ToDouble(Console.ReadLine());
		 
		 Console.Write("Nilai Kuis      : ");
		 double kuis = Convert.ToDouble(Console.ReadLine());
  
		 Console.Write("Nilai UTS       : ");
		 double uts = Convert.ToDouble(Console.ReadLine());
		 
		 Console.Write("Nilai UAS       : ");
		 double uas = Convert.ToDouble(Console.ReadLine());
  
	
		 double hitung = (kehadiran*0.05) + (tugas*0.25) + (kuis*0.15) + (uts*0.25) + (uas*0.30);
		 
		 Console.WriteLine("===============≠============= \t");
		 
		 if (hitung >= 73) {
		 
		     Console.WriteLine($"Nilai = {hitung} ");
				 Console.WriteLine("Tuntas KKM");
		 }
		 
		 else {
		 
		    Console.WriteLine($"Nilai = {hitung}");
				Console.WriteLine("Remidial");
		 }
  
	
	
	
	}
	
}


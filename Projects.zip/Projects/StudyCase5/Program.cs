﻿using System;
using System.Linq;

// Create by NurFakhri | @nurfakhri.id
public static class Program
{
  public static void Main()
  {	
    
		double panjang, lebar, luas;
		
		Console.WriteLine("PROGRAM HITUNG LUAS PERSEGI PANJANG\n");
		
		Console.Write("PANJANG :  ");
		panjang = Convert.ToDouble(Console.ReadLine());
		
		Console.Write("LEBAR   :  ");
		lebar = Convert.ToDouble(Console.ReadLine());
		
		
		luas = panjang * lebar;
		
		Console.Write("\n Luas persegi panjang adalah : " + luas + "cm");
		
		
		
		
		
		
		
  }
}

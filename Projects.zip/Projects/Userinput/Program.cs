﻿



using System;
using System.Linq;

namespace Userinput;

public static class Program
{
	public static void Main()
	{
		
		
    Console.Write("Masukan nama lengkap          : ");
		string nama = Console.ReadLine();
		Console.Write("Masukan tempat/tanggal lahir  : ");
		string tempat = Console.ReadLine();
		Console.Write("Masukan alamat                : ");
		string alamat = Console.ReadLine();
		Console.Write("Masukan no telepon            : ");
		string no = Console.ReadLine();
		
		
		Console.WriteLine("\n================== Data Peserta ===================");
		Console.WriteLine("Nama                 : " + nama);
		Console.WriteLine("Tempat/tanggal lahir : " + tempat);
		Console.WriteLine("Alamat               : " + alamat);
		Console.WriteLine("Nomer telepon        : " + no);
		Console.WriteLine("============== Telah Berhasil Di Rekam ============ ");
		
		
	}
}


﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Program Menghitung Rata-rata Nilai Siswa");
        Console.WriteLine("___________________________________________");
      
        string[] namaSiswa = new string[5];
        double[] nilaiSiswa = new double[5];


        for (int i = 0; i < 5; i++)
        {
            Console.Write("Masukkan nama siswa ke-{0}: ", i + 1);
            namaSiswa[i] = Console.ReadLine();

            Console.Write("Masukkan nilai siswa {0}: ", i + 1);
            nilaiSiswa[i] = Convert.ToDouble(Console.ReadLine());
        }

    
        double totalNilai = 0;
        for (int i = 0; i < 5; i++)
        {
            totalNilai += nilaiSiswa[i];
        }
        double rataRata = totalNilai / 5;

        Console.WriteLine("_______________________________________________");
        Console.WriteLine("\nDaftar Nama Siswa dan Nilai:");
        for (int i = 0; i < 5; i++)
        {
            Console.WriteLine("Nama Siswa: " + namaSiswa[i]);
            Console.WriteLine("Nilai: " + nilaiSiswa[i]);
        }
        Console.WriteLine("Rata-rata Nilai Siswa: " + rataRata);
        Console.ReadKey();
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

//Created by NurFakhri

namespace studycase14
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("PROGRAM SELEKSI NILAI");

            Console.Write("Nilai siswa: ");
            double nilai = Convert.ToDouble(Console.ReadLine());
            
            if (nilai >= 73) {
						
            Console.WriteLine("Nilai: " + nilai);
            Console.WriteLine("Tuntas KKM");
             }
             
            else {	
            Console.WriteLine ("Nilai: " + nilai );
            Console.WriteLine ("Remidial");
						 }

        }
    }
}
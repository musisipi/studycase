﻿using System;
using System.Linq;

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Program Membandingkan Dua Nilai");


            Console.Write("Masukkan nilai pertama: ");
            double nilai1 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Masukkan nilai kedua: ");
            double nilai2 = Convert.ToDouble(Console.ReadLine());


        bool samaDengan = nilai1 == nilai2;
        bool tidakSamaDengan = nilai1 != nilai2;
        bool kurangDari = nilai1 < nilai2;
        bool lebihDari = nilai1 > nilai2;
        bool kurangSamaDengan = nilai1 <= nilai2;
        bool lebihSamaDengan = nilai1 >= nilai2;

  
        Console.WriteLine("Hasil perbandingan:");
        Console.WriteLine("Nilai1 == Nilai2:" + samaDengan);
        Console.WriteLine("Nilai1 != Nilai2:" + tidakSamaDengan);
        Console.WriteLine("Nilai1 < Nilai2:" + kurangDari);
        Console.WriteLine("Nilai1 > Nilai2:" + lebihDari);
        Console.WriteLine("Nilai1 <= Nilai2:" + kurangSamaDengan);
        Console.WriteLine("Nilai1 >= Nilai2:" + lebihSamaDengan);
        }
    }

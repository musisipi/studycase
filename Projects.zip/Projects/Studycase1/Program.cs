﻿



/* Simple program Create By NurFakhri
   C# Programming  
*/ 

using System;
using System.Linq;

namespace Studycase1;

public static class Program
{
	public static void Main()
	{	
    Console.WriteLine("Halll, Perkenalkan, nama saya\n");
	  Console.WriteLine("Nama         : MUHAMMAD NUR FAKHRI");
	  Console.WriteLine("Sekolah      : SMKN 1 BANTUL");
	  Console.WriteLine("Kelas        : X RPL 2");
	  Console.WriteLine("Berat badan  : 54kg");
	  Console.WriteLine("Tinggi badan : 174cm");
	  
	  Console.WriteLine("\nSekian perkenalan dari saya, terimakasih");
	  
	  
	}
}

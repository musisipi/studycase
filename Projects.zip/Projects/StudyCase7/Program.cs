﻿using System;
using System.Linq;

namespace StudyCase7;

public static class Program
{
  public static void Main()
  {
		
		double p, l, t, vol, kel;
		
		Console.WriteLine("PROGRAM MENGHITUNG KELILING DAN VOLUME BALOK");
		
		Console.Write("Panjang  : ");
		p = Convert.ToDouble(Console.ReadLine());
		
		Console.Write("Lebar    : ");
		l = Convert.ToDouble(Console.ReadLine());
		
		Console.Write("Tinggi   : ");
		t = Convert.ToDouble(Console.ReadLine());
		
		
		vol = p * l * t;
		kel = 4 * (p+l+t);
		
		Console.WriteLine("\nVolume balok adalah  " + vol);
		Console.WriteLine("Keliling balok adalah  " + kel);
		
		//Create By NurFakhri || @nurfakhri.id
		
  }
}
